(self["webpackChunkbabel_core_demo"] = self["webpackChunkbabel_core_demo"] || []).push([[34],{

/***/ "./src/router/category.js":
/*!********************************!*\
  !*** ./src/router/category.js ***!
  \********************************/
/***/ (function() {

var h1 = document.createElement('h1');
h1.textContent = "Category Page";
document.body.append(h1);

/***/ })

}]);