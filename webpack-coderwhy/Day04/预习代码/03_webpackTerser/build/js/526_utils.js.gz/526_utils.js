"use strict";
(self["webpackChunkbabel_core_demo"] = self["webpackChunkbabel_core_demo"] || []).push([[526],{

/***/ "./src/utils/foo.js":
/*!**************************!*\
  !*** ./src/utils/foo.js ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "foo": function() { return /* binding */ foo; }
/* harmony export */ });
function foo() {
  console.log('foo function exec~');
}

// 代码很多, 大于20kb

/***/ })

}]);