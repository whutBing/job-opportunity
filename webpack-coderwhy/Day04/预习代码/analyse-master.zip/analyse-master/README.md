# analyse

[http://webpack.github.com/analyse](http://webpack.github.com/analyse)

## Running

You can generate the required JSON file for this tool by running `webpack --profile --json > stats.json`

## Build

Development:

``` text
grunt dev
```

Production:

``` text
grunt
```

Publish:

``` text
grunt deploy
```
